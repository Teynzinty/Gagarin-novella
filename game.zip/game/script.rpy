﻿# Определяем персонажей
define g = Character("Юрий Гагарин", who_color="#333333")
define korolev = Character("Сергей Королёв", who_color="#333333")
define kamanin = Character("Генерал Каманин", who_color="#333333")
define komandir = Character("Командир", who_color="#333333")
define instruktor = Character("Инструктор", who_color="#333333")
define letchik = Character("Раненый лётчик", who_color="#333333")
define mat = Character("Мама", who_color="#333333")
define zhenchina = Character("Женщина", who_color="333333")

# Объявляем переменные
default mushestvo = 0
default aviatsiya = 0
default gagarin_points = 0

label start:
    scene little gagarin :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    play music "heart.mp3" volume 0.25
    show text "{size=*4}{color=#000000}12 апреля 1961 года{/color}{/size}" at truecenter with dissolve
    pause 2
    hide text with dissolve

    show text "{size=*4}{color=#000000}Ты — Юрий Гагарин{/color}{/size}" at truecenter with dissolve
    pause 2
    hide text with dissolve

    jump chapter1

# Глава 1. Детство в Клушино
label chapter1:
    scene klushino :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Деревня Клушино, 1941 год."
    "Немцы оккупировали деревню. Твоей семье пришлось перебраться в землянку, вырытой в огороде."
    "Ты видишь как мама плачет по ночам, а отец становится все мрачнее, но не можешь помочь."
    scene raneniy :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Отец спрятал в сарае раненого советского лётчика. Тот был без сознания с пробитой рукой."
    scene mama :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    mat "Юра, никому ни слова! Если узнают немцы — расстреляют всех."
    scene letchik :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    letchik "Мальчик... помоги. Воды."

    menu:
        "Что ты сделаешь?"
        "Каждый день носить лётчику еду и воду, рискуя быть пойманным немцами":
            $ mushestvo += 5
            scene voda :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Ты тайком пробираешься в сарай с едой. Сердце колотится от страха, но ты не отступаешь."
            "Каждые несколько дней ты приносишь летчику еду и воду, надеясь, что он выживает."
            scene udivlen :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "В один из дней ты обнаруживаешь, что в сарае его нет."
            scene zapisca :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "На полу лежит записка:"
            scene zapisca2 :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            letchik "Спасибо, парень. Ты спас мне жизнь. Лети выше всех — это твоё небо."
            "Эти слова западают тебе в душу навсегда..."
            "Летчик выжил и ты был тем, кто спас его."
        "Слушаться маму и не высовываться":
            scene malish :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            stop music fadeout 4.0
            "Ты остаёшься в землянке, боясь немцев. Однажды ночью раздаются выстрелы."
            scene ruki :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            mat "Не смотри, Юрочка... закрой глаза..."
            scene smert :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Лётчика нашли."
            scene smert2 :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            play sound "vistrel.mp3" volume 0.5
            "Ты слышишь крики, выстрел, а потом — тишину."
            scene smert3 :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Горечь от этой потери останется с тобой навсегда."
            $ mushestvo -= 5
    scene gjetsk :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Война заканчивается. Твоя семья переезжает в Гжатск."
    scene nebo :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Но небо..."
    "Ты уже не можешь забыть его."
    stop music fadeout 2.0

    jump chapter2

# Глава 2. Люберцы
label chapter2:
    scene uchilise :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    play music "glava2.mp3" volume 0.25
    "1949 год. Москва. Люберецкое ремесленное училище."
    scene chelik :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Ты поступаешь на литейщика." 
    "Днём — учёба и работа на заводе."
    scene gul :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "А по вечерам... ты слышишь гул самолётов над головой."
    "Рядом — аэроклуб."

    menu:
        "Чем ты займёшься в свободное время?"
        "Записаться в аэроклуб. Бегать 5 километров до аэродрома каждые выходные":
            $ aviatsiya += 10
            scene ran :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Ты встаёшь затемно." 
            "Бежишь через весь город. Ноги стираешь в кровь."
            scene radost :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Но впервые в жизни ты видишь кабину самолёта."
            "Запах бензина и неба — это пьянит."
            scene radost2 :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            instruktor "Смотри, Гагарин! Худой, но глаза горят. Оставь его — выйдет толк."
            "Каждый будний день ты с нетерпением ждешь выходных. Чтобы снова оказаться в аэроклубе."
        "Помогать маме и работать сверхурочно на заводе":
            $ aviatsiya -= 5
            scene mama2 :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Ты откладываешь мечту. Семья нуждается в деньгах."
            scene chelik :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Ты стоишь у печи, плавишь металл, а в голове — самолёты."
            "Но время уходит. Тебе уже 17."
    scene fon :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Однажды учитель замечает твой интерес к небу."
    show instruktor :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Инструктор: Гагарин, а хочешь научиться прыгать с парашютом?"
    hide instruktor
    show gagarin :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    g "А это... трудно?"
    hide gagarin
    show instruktor :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Инструктор: Трудно. Но ты справишься. Упрямый ты."
    hide instruktor
    stop music fadeout 2.0

    jump chapter3

# Глава 3. Саратов
label chapter3:
    scene student :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    play music "glava3.mp3" volume 0.25
    "1951 год. Саратовский индустриальный техникум."
    "Ты продолжаешь учиться, но главное — рядом аэроклуб."
    scene samolet :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Первый прыжок с парашютом."
    show kirio :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Ты стоишь у открытой двери самолёта. Ветер бьёт в лицо. Высота 800 метров."
    hide kirio
    show instruktor :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    instruktor "Боишься, Гагарин?"
    hide instruktor

    menu:
        "Твой ответ инструктору:"
        "\"Страшно. Но я должен научиться.\"":
            $ mushestvo += 5
            show instruktor :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            instruktor "Честность — это хорошо. Запомни: страх не враг. Враг — паника. Давай!"
            hide instruktor
            scene chag :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Ты делаешь шаг в пустоту. Несколько секунд ужаса — и купол раскрывается."
            scene pupupu :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Тишина. Ты паришь над Волгой. Впервые в жизни ты чувствуешь себя свободным."
        "\"Нет, я ничего не боюсь!\"":
            $ mushestvo -= 5
            scene chag :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Ты прыгаешь с бравадой, но в воздухе путаешь стропы."
            scene durak :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Земля приближается слишком быстро. Инструктор кричит по рации."
            instruktor "Дёрни запасное кольцо, дурак!"
            scene prit :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Ты едва успеваешь. Приземление жёсткое. Инструктор ругается."
            instruktor "Не ври себе, Гагарин. Страх — норма. Ложь — убивает."
    scene reshenie :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "После прыжка ты твёрдо решаешь: стану лётчиком."
    scene okonchanie :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Ты заканчиваешь аэроклуб с отличием."
    stop music fadeout 2.0

    jump chapter4

# Глава 4. Оренбургское лётное училище
label chapter4:
    scene polet :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    play music "sweet.mp3" volume 0.15
    "1955 год. Оренбург. Военное авиационное училище лётчиков."
    "Зимой — мороз под 30 градусов. Самолёты МиГ-15 стоят, покрытые инеем."
    scene polet2 :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Ты совершаешь учебный полёт." 
    scene vverh :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "На посадке — ошибка. Самолёт заваливается на крыло. Командир хватается за штурвал."
    scene kabinet :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "После посадки тебя вызывают на ковер."
    show komandir :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"

    komandir "Гагарин! Ты чуть не разбился! Что случилось?"

    menu:
        "Твои действия:"
        "Честно признаться: отвлёкся на приборную доску":
            $ mushestvo += 5
            komandir "Приборы — второе. Глаза — первые. Садись, больше так не делай."
            hide komandir
            "Командир оставляет тебя в группе. Ты получаешь второй шанс."
        "Сказать, что виноват ветер":
            $ mushestvo -= 5
            komandir "Врёшь, Гагарин. Ветра не было. Дополнительные полёты."
            hide komandir
            "Ты летаешь ещё 10 часов, пока не докажешь, что ошибка была случайной."
            "Но осадочек остаётся."
        "Попросить ещё один полёт прямо сейчас":
            $ mushestvo += 10
            $ aviatsiya += 5
            hide komandir
            show  kirio :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            g "Разрешите ещё один заход, товарищ командир! Я докажу."
            hide kirio
            show komandir :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            komandir "Смелый... Ладно. Давай."
            hide komandir
            scene posadka :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Ты садишься идеально. Командир хлопает тебя по плечу."
            komandir "Характер есть, Гагарин. Лётчик из тебя выйдет."
    

    scene okonchanie2 :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Ты оканчиваешь училище с отличием. Летишь на МиГ-17 на Северный флот."
    stop music fadeout 2.0

    jump chapter5

# Глава 5. Отбор в отряд космонавтов
label chapter5:
    scene center :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    play music "glava5.mp3" volume 0.25
    "1959 год. Москва. Центр подготовки космонавтов."
    "20 лучших лётчиков страны. 3 места. Ты — один из них."
    "Тебя вызывают к генералу Каманину."
    show kamanin :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"

    kamanin "Гагарин. Твой рост — 157 сантиметров. Ты самый низкий."
    kamanin "Но именно поэтому ты подходишь для корабля \"Восток\" — там мало места."
    kamanin "Ответь: почему ты должен лететь первым?"

    menu:
        "Твой ответ генералу:"
        "\"Потому что я лучше всех подготовлен. Я лучший.\"":
            $ mushestvo -= 10
            kamanin "Гордыня — плохой советчик. Ты силён, но самоуверен."
            "Каманин хмурится. Ты теряешь баллы в глазах комиссии."
        "\"Я люблю небо с детства. Я не подведу страну. Отправьте меня — и я сделаю всё.\"":
            $ mushestvo += 10
            kamanin "Скромный, но твёрдый. Хороший ответ. Я тебя запомнил."

    hide kamanin
    "Комиссия принимает решение: Гагарин — в числе трёх финалистов."
    "Твой соперник — Герман Титов. Но выбор всё ещё за Каманиным и Королёвым."
    stop music fadeout 2.0

    jump chapter6

# Глава 6. 12 апреля 1961 года
label chapter6:
    scene raketa :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    play music "Champion.mp3" volume 0.15
    "Байконур. Раннее утро 12 апреля 1961 года."
    "Ракета Р-7 стоит на старте. Ты в скафандре. Идёшь к лифту."
    show korolev :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    korolev "Гагарин, волнуешься?"
    hide korolev
    show gagarin10 :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    g "Своими делами надо гордиться, а не волноваться, Сергей Павлович."
    hide gagarin10
   
    "Королёв улыбается. Ты заходишь в лифт. Подъём на 40 метров."
    scene korabl :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Кабина корабля «Восток». Теснота. Кнопки. Иллюминатор."
    show zhurnal :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Перед стартом тебе дают бортовой журнал. Можно записать любую фразу."

    menu:
        "Что ты напишешь в бортовом журнале?"
        "\"Летим! Выполню задание любой ценой.\"":
            show ruchka :
             xalign 0.5 yalign 0.5
            g "Летим! Выполню задание любой ценой."
            "Строка. Солдатская. Правильная. Но не твоя."
        "\"Поехали!\"":
            $ gagarin_points += 1
            show ruchka :
             xalign 0.5 yalign 0.5
            g "Поехали!"
            "Ты улыбаешься. Слова сами срываются с языка. Простые. Человечные."
            "Именно эта фраза войдёт в историю."
        "\"Мама, я в небе. Прости, что не сказал.\"":
            show ruchka :
             xalign 0.5 yalign 0.5
            g "Мама, я в небе..."
            "Ты вспоминаешь её лицо. Глаза наполняются влагой."
            "Королёв по рации: \"Гагарин, не раскисай! У нас работа!\""
    hide ruchka
    hide zhurnal
    "Обратный отсчёт: 10, 9, 8..."
    "Пуск."

    scene peregruz :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Перегрузка. 3G... 5G... 6G. Твоё лицо искажается."
    "Но ты держишься. Вспоминаешь тренировки. Центрифугу."
    scene nevesomost :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Гул стихает. Невесомость."
    
    "Ты отстёгиваешь ремни. Паришь в кабине. Карандаш летает перед глазами."
    scene zemla :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Смотришь в иллюминатор."

    g "Вижу горизонт Земли... Красота-то какая!"

    "Голубая планета. Тонкая атмосфера. Космос — чёрный, бесконечный."
    scene pan :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Вдруг — аварийный сигнал. Тормозная система не отключается."
    "Корабль начинает вращаться. 10 минут агонии."

    "Земля: \"Гагарин, как слышите? Приём!\""
    "Ты можешь запаниковать. Но ты знаешь: паника — враг."

    menu:
        "Как ты сохранишь спокойствие?"
        "Начну считать секунды до расчётного времени":
            scene shet :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            "Один... два... три... сбиваешься. Сто пять... чёрт."
            "Страх мешает считать. Сердце колотится."
            g "Небольшие проблемы, но контролирую ситуацию."
        "Начну петь песню":
            scene pesna :
             xalign 0.5 yalign 0.5
             zoom 1.2
             fit "cover"
            g "Родина слышит, Родина знает..."
            "Ты поёшь. Голос дрожит, но ты не сдаёшься."
            "Пение успокаивает. Ты перестаёшь думать о смерти."
            g "Все штатно, идем на посадку."
    scene spusk :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Через 10 минут автоматика срабатывает. Тормозная система включается."
    "Корабль идёт на спуск."

    jump ending

# Финал
label ending:
    scene spuskk :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Спускаемый аппарат входит в атмосферу. Скафандр спасёт тебя."
    scene vse :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "На высоте 7 километров катапульта срабатывает."
    scene pole :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    "Ты приземляешься в поле под Саратовом."

    "К тебе бежит женщина с девочкой."
    show zhenchina :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    zhenchina "Ой, батюшки! А вы кто? Не с неба ли?"
    hide zhenchina
    show gagarin10 :
     xalign 0.5 yalign 0.5
     zoom 1.2
     fit "cover"
    g "Да... С неба."
    hide gagarin10

    if gagarin_points > 0 and mushestvo >= 10:
        jump ending_good
    elif mushestvo >= 5 and aviatsiya >= 5:
        jump ending_pilot
    elif mushestvo <= 0:
        jump ending_bad
    else:
        jump ending_normal

label ending_good:
    "Женщина крестится. Девочка смеётся."
    "Ты снимаешь шлем. Улыбаешься."
    "108 минут полёта. Один человек. Тысячи лет мечты."

    "Концовка: ПОЕХАЛИ!"

    "Юрий Гагарин сказал «Поехали» — и человечество стало межпланетным."
    "Ты прожил его жизнь. Ты знаешь: космос начинается с выбора."
    "С Днём космонавтики!"

    return

label ending_pilot:
    "Ты приземляешься. Женщина помогает встать."
    "Ты не Гагарин. Ты просто хороший лётчик."
    "Но ты сделал свой выбор. Ты остался с небом."

    "Концовка: ЛЁТЧИК-ИСПЫТАТЕЛЬ"

    "Ты будешь летать на новых самолётах. Может быть, когда-нибудь... в космосе."
    "Но не сегодня."

    return

label ending_bad:
    "Ты лежишь в поле. Скафандр тяжёлый. На душе пусто."
    "Женщина спрашивает: \"Ты кто?\""
    "Ты молчишь. Потому что сам не знаешь ответа."

    "Концовка: ЗАБЫТЫЙ ПРЕТЕНДЕНТ"

    "История запомнит Гагарина. Но не тебя."
    "Страх и неуверенность не пускают к звёздам."

    return

label ending_normal:
    "Ты садишься на траву. Улыбаешься женщине."
    "Ты жив. Ты летал. Ты не подвёл."

    "Концовка: ТЫ ВЫЖИЛ. НО НЕ СТАЛ ЛЕГЕНДОЙ"

    "Ты вернёшься на Землю. Будешь тренировать новых космонавтов."
    "Гагариным станет кто-то другой. Но ты был рядом."
    return
